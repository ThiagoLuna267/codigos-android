package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Toast.makeText( MainActivity.this, "a activity main foi criada.(onCreate)", Toast.LENGTH_SHORT).show();
        setContentView(R.layout.activity_main);
        final EditText text = (EditText)findViewById(R.id.Digi);
        text.setText("");

        final ProgressBar pBar =
                (ProgressBar)findViewById(R.id.progressBar);
        pBar.setVisibility(View.INVISIBLE);

        final Button button =  (Button)findViewById(R.id.button2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CEPAsyncTask task = new CEPAsyncTask(pBar, button);
                task.execute(text.getText().toString());
            }
        });
    }

    protected void onStart(){
        super.onStart();
        Toast.makeText(MainActivity.this, "a activity main foi iniciada.(onStart)", Toast.LENGTH_SHORT).show();
    }
    protected void onResume(){
        super.onResume();
        Toast.makeText(MainActivity.this, "a activity main foi continuada.(onResume)", Toast.LENGTH_SHORT).show();
    }
    protected void onRestart() {
        super.onRestart();
        Toast.makeText(MainActivity.this, "a activity main foi reiniciada.(onRestart)", Toast.LENGTH_SHORT).show();
    }

    protected void onPause() {
        super.onPause();
        Toast.makeText(MainActivity.this, "a activity main foi pausada.(onPause)", Toast.LENGTH_SHORT).show();
    }
    protected void onStop() {
        super.onStop();
        Toast.makeText(MainActivity.this, "a activity main foi parada.(onStop)", Toast.LENGTH_SHORT).show();
    }
    protected void onDestroy() {

        Toast.makeText(MainActivity.this, "a activity main será destroída.(onDestroy)", Toast.LENGTH_SHORT).show();
        super.onDestroy();
    }

}
